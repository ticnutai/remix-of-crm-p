import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppLayout } from '@/components/layout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/hooks/useAuth';
import { useTasks, Task, TaskInsert } from '@/hooks/useTasks';
import { useMeetings, Meeting, MeetingInsert } from '@/hooks/useMeetings';
import { supabase } from '@/integrations/supabase/client';
import {
  Plus,
  CheckSquare,
  Clock,
  Calendar,
  User,
  Briefcase,
  Trash2,
  Edit,
  Loader2,
  AlertCircle,
  ArrowUp,
  ArrowRight,
  ArrowDown,
  MapPin,
  Users,
  Video,
  Phone,
  ClipboardList,
  GripVertical,
} from 'lucide-react';
import { format, parseISO, isPast, isToday } from 'date-fns';
import { he } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

// Task constants
const priorities = [
  { value: 'low', label: 'נמוכה', icon: ArrowDown, color: 'text-green-600' },
  { value: 'medium', label: 'בינונית', icon: ArrowRight, color: 'text-yellow-600' },
  { value: 'high', label: 'גבוהה', icon: ArrowUp, color: 'text-red-600' },
];

const statuses = [
  { value: 'pending', label: 'ממתין' },
  { value: 'in_progress', label: 'בביצוע' },
  { value: 'completed', label: 'הושלם' },
];

// Meeting constants
const meetingTypes = [
  { value: 'in_person', label: 'פגישה פיזית', icon: Users },
  { value: 'video', label: 'שיחת וידאו', icon: Video },
  { value: 'phone', label: 'שיחת טלפון', icon: Phone },
];

const statusColors: Record<string, string> = {
  scheduled: 'bg-blue-100 text-blue-800',
  completed: 'bg-green-100 text-green-800',
  cancelled: 'bg-red-100 text-red-800',
};

// Sortable Task Item Component
interface SortableTaskItemProps {
  task: Task;
  index: number;
  onEdit: (task: Task) => void;
  onDelete: (id: string) => void;
  onToggleComplete: (task: Task) => void;
  getPriorityInfo: (priority: string) => { value: string; label: string; icon: any; color: string };
}

const SortableTaskItem: React.FC<SortableTaskItemProps> = ({
  task,
  index,
  onEdit,
  onDelete,
  onToggleComplete,
  getPriorityInfo,
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const priorityInfo = getPriorityInfo(task.priority);
  const PriorityIcon = priorityInfo.icon;
  const isOverdue = task.due_date && isPast(parseISO(task.due_date)) && task.status !== 'completed';
  const isDueToday = task.due_date && isToday(parseISO(task.due_date));

  return (
    <Card
      ref={setNodeRef}
      style={style}
      className={cn(
        "hover:shadow-md transition-shadow",
        task.status === 'completed' && "opacity-60",
        isOverdue && "border-destructive"
      )}
    >
      <CardContent className="p-4">
        <div className="flex items-center gap-4 flex-row-reverse">
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onEdit(task)}
            >
              <Edit className="h-4 w-4 text-black" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(task.id)}
            >
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          </div>

          <div className="flex-1 text-right">
            <div className="flex items-center gap-2 justify-end">
              <span className="text-sm font-bold text-black bg-yellow-100 px-2 py-0.5 rounded">
                #{index + 1}
              </span>
              <PriorityIcon className={cn("h-4 w-4", priorityInfo.color)} />
              <h3 className={cn(
                "font-medium text-black",
                task.status === 'completed' && "line-through"
              )}>
                {task.title}
              </h3>
            </div>

            <div className="flex items-center gap-4 text-sm text-black mt-1 justify-end">
              {task.assignee?.full_name && (
                <span className="flex items-center gap-1">
                  {task.assignee.full_name}
                  <User className="h-3 w-3" />
                </span>
              )}
              {task.due_date && (
                <span className={cn(
                  "flex items-center gap-1",
                  isOverdue && "text-destructive",
                  isDueToday && "text-yellow-600"
                )}>
                  {format(parseISO(task.due_date), 'dd/MM/yyyy HH:mm', { locale: he })}
                  <Calendar className="h-3 w-3" />
                  {isOverdue && <AlertCircle className="h-3 w-3" />}
                </span>
              )}
            </div>

            <div className="flex items-center gap-2 mt-2 justify-end">
              {task.project?.name && (
                <Badge variant="outline" className="text-black">
                  {task.project.name}
                  <Briefcase className="h-3 w-3 mr-1" />
                </Badge>
              )}
              {task.client?.name && (
                <Badge variant="outline" className="text-black">
                  {task.client.name}
                  <User className="h-3 w-3 mr-1" />
                </Badge>
              )}
              <Badge variant={
                task.status === 'completed' ? 'secondary' :
                task.status === 'in_progress' ? 'default' : 'outline'
              } className="text-black">
                {statuses.find(s => s.value === task.status)?.label}
              </Badge>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Checkbox
              checked={task.status === 'completed'}
              onCheckedChange={() => onToggleComplete(task)}
              className="h-5 w-5"
            />
            <div
              {...attributes}
              {...listeners}
              className="cursor-grab active:cursor-grabbing p-1 hover:bg-gray-100 rounded"
            >
              <GripVertical className="h-5 w-5 text-gray-400" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const TasksAndMeetings = () => {
  const navigate = useNavigate();
  const { user, isLoading: authLoading } = useAuth();
  const { tasks, loading: tasksLoading, createTask, updateTask, deleteTask } = useTasks();
  const { meetings, loading: meetingsLoading, createMeeting, updateMeeting, deleteMeeting } = useMeetings();
  
  const [activeTab, setActiveTab] = useState('tasks');
  
  // Task state
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskFilter, setTaskFilter] = useState('all');
  const [sortedTasks, setSortedTasks] = useState<Task[]>([]);
  
  // Meeting state
  const [meetingDialogOpen, setMeetingDialogOpen] = useState(false);
  const [editingMeeting, setEditingMeeting] = useState<Meeting | null>(null);
  
  // Shared data
  const [clients, setClients] = useState<{ id: string; name: string }[]>([]);
  const [projects, setProjects] = useState<{ id: string; name: string }[]>([]);
  const [employees, setEmployees] = useState<{ id: string; full_name: string }[]>([]);
  
  // Task form
  const [taskForm, setTaskForm] = useState<TaskInsert>({
    title: '',
    description: '',
    status: 'pending',
    priority: 'medium',
    due_date: null,
    assigned_to: null,
    client_id: null,
    project_id: null,
    tags: [],
  });
  
  // Meeting form
  const [meetingForm, setMeetingForm] = useState<MeetingInsert>({
    title: '',
    description: '',
    start_time: '',
    end_time: '',
    location: '',
    meeting_type: 'in_person',
    client_id: null,
    project_id: null,
    attendees: [],
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    const fetchData = async () => {
      const [clientsRes, projectsRes, employeesRes] = await Promise.all([
        supabase.from('clients').select('id, name').order('name'),
        supabase.from('projects').select('id, name').order('name'),
        supabase.from('profiles').select('id, full_name').order('full_name'),
      ]);

      if (clientsRes.data) setClients(clientsRes.data);
      if (projectsRes.data) setProjects(projectsRes.data);
      if (employeesRes.data) setEmployees(employeesRes.data);
    };

    if (user) fetchData();
  }, [user]);

  // Task handlers
  const resetTaskForm = () => {
    setTaskForm({
      title: '',
      description: '',
      status: 'pending',
      priority: 'medium',
      due_date: null,
      assigned_to: null,
      client_id: null,
      project_id: null,
      tags: [],
    });
    setEditingTask(null);
  };

  const handleTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingTask) {
      await updateTask(editingTask.id, taskForm);
    } else {
      await createTask(taskForm);
    }
    
    setTaskDialogOpen(false);
    resetTaskForm();
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setTaskForm({
      title: task.title,
      description: task.description || '',
      status: task.status,
      priority: task.priority,
      due_date: task.due_date,
      assigned_to: task.assigned_to,
      client_id: task.client_id,
      project_id: task.project_id,
      tags: task.tags || [],
    });
    setTaskDialogOpen(true);
  };

  const handleDeleteTask = async (id: string) => {
    if (confirm('האם למחוק את המשימה?')) {
      await deleteTask(id);
    }
  };

  const handleToggleComplete = async (task: Task) => {
    const newStatus = task.status === 'completed' ? 'pending' : 'completed';
    await updateTask(task.id, { status: newStatus });
  };

  // Meeting handlers
  const resetMeetingForm = () => {
    setMeetingForm({
      title: '',
      description: '',
      start_time: '',
      end_time: '',
      location: '',
      meeting_type: 'in_person',
      client_id: null,
      project_id: null,
      attendees: [],
    });
    setEditingMeeting(null);
  };

  const handleMeetingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingMeeting) {
      await updateMeeting(editingMeeting.id, meetingForm);
    } else {
      await createMeeting(meetingForm);
    }
    
    setMeetingDialogOpen(false);
    resetMeetingForm();
  };

  const handleEditMeeting = (meeting: Meeting) => {
    setEditingMeeting(meeting);
    setMeetingForm({
      title: meeting.title,
      description: meeting.description || '',
      start_time: meeting.start_time.slice(0, 16),
      end_time: meeting.end_time.slice(0, 16),
      location: meeting.location || '',
      meeting_type: meeting.meeting_type,
      client_id: meeting.client_id,
      project_id: meeting.project_id,
      attendees: meeting.attendees || [],
    });
    setMeetingDialogOpen(true);
  };

  const handleDeleteMeeting = async (id: string) => {
    if (confirm('האם למחוק את הפגישה?')) {
      await deleteMeeting(id);
    }
  };

  const getTypeIcon = (type: string) => {
    const found = meetingTypes.find(t => t.value === type);
    return found ? found.icon : Users;
  };

  const getPriorityInfo = (priority: string) => {
    return priorities.find(p => p.value === priority) || priorities[1];
  };

  // Update sortedTasks when tasks or filter changes
  useEffect(() => {
    const filtered = tasks.filter(task => {
      if (taskFilter === 'all') return true;
      if (taskFilter === 'pending') return task.status === 'pending';
      if (taskFilter === 'in_progress') return task.status === 'in_progress';
      if (taskFilter === 'completed') return task.status === 'completed';
      if (taskFilter === 'overdue') return task.due_date && isPast(parseISO(task.due_date)) && task.status !== 'completed';
      return true;
    });
    setSortedTasks(filtered);
  }, [tasks, taskFilter]);

  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setSortedTasks((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id);
        const newIndex = items.findIndex((item) => item.id === over.id);
        
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) return null;

  const pendingCount = tasks.filter(t => t.status === 'pending').length;
  const inProgressCount = tasks.filter(t => t.status === 'in_progress').length;
  const completedCount = tasks.filter(t => t.status === 'completed').length;
  const overdueCount = tasks.filter(t => t.due_date && isPast(parseISO(t.due_date)) && t.status !== 'completed').length;

  return (
    <AppLayout title="משימות ופגישות">
      <div className="p-6 md:p-8" dir="rtl">
        {/* Header */}
        <div className="flex items-center gap-3 mb-6 text-right">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[hsl(45,80%,45%)]/10">
            <ClipboardList className="h-6 w-6 text-[hsl(45,80%,45%)]" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">משימות ופגישות</h1>
            <p className="text-muted-foreground text-sm">ניהול משימות ופגישות במקום אחד</p>
          </div>
        </div>

        {/* Main Tabs - Tasks and Meetings */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="tasks" className="gap-2">
              <CheckSquare className="h-4 w-4" />
              משימות ({tasks.length})
            </TabsTrigger>
            <TabsTrigger value="meetings" className="gap-2">
              <Calendar className="h-4 w-4" />
              פגישות ({meetings.length})
            </TabsTrigger>
          </TabsList>

          {/* Tasks Tab */}
          <TabsContent value="tasks" className="space-y-4">
            <div className="flex items-center justify-between">
              <Tabs value={taskFilter} onValueChange={setTaskFilter}>
                <TabsList>
                  <TabsTrigger value="all">הכל ({tasks.length})</TabsTrigger>
                  <TabsTrigger value="pending">ממתין ({pendingCount})</TabsTrigger>
                  <TabsTrigger value="in_progress">בביצוע ({inProgressCount})</TabsTrigger>
                  <TabsTrigger value="completed">הושלם ({completedCount})</TabsTrigger>
                  {overdueCount > 0 && (
                    <TabsTrigger value="overdue" className="text-destructive">
                      באיחור ({overdueCount})
                    </TabsTrigger>
                  )}
                </TabsList>
              </Tabs>
              
              <Dialog open={taskDialogOpen} onOpenChange={(open) => {
                setTaskDialogOpen(open);
                if (!open) resetTaskForm();
              }}>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    משימה חדשה
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg" dir="rtl">
                  <DialogHeader>
                    <DialogTitle className="text-black">{editingTask ? 'עריכת משימה' : 'משימה חדשה'}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleTaskSubmit} className="space-y-4 text-right">
                    <div>
                      <Label className="text-right block text-black">כותרת *</Label>
                      <Input
                        value={taskForm.title}
                        onChange={(e) => setTaskForm({ ...taskForm, title: e.target.value })}
                        required
                        className="text-black"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-right block text-black">סטטוס</Label>
                        <Select
                          value={taskForm.status}
                          onValueChange={(value) => setTaskForm({ ...taskForm, status: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {statuses.map(status => (
                              <SelectItem key={status.value} value={status.value}>
                                {status.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-right block text-black">עדיפות</Label>
                        <Select
                          value={taskForm.priority}
                          onValueChange={(value) => setTaskForm({ ...taskForm, priority: value })}
                        >
                          <SelectTrigger className="text-black">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {priorities.map(priority => (
                              <SelectItem key={priority.value} value={priority.value} className="text-black">
                                {priority.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-right block text-black">תאריך יעד</Label>
                        <Input
                          type="datetime-local"
                          value={taskForm.due_date || ''}
                          onChange={(e) => setTaskForm({ ...taskForm, due_date: e.target.value || null })}
                          className="text-black"
                        />
                      </div>
                      <div>
                        <Label className="text-right block text-black">משויך ל</Label>
                        <Select
                          value={taskForm.assigned_to || 'none'}
                          onValueChange={(value) => setTaskForm({ ...taskForm, assigned_to: value === 'none' ? null : value })}
                        >
                          <SelectTrigger className="text-black">
                            <SelectValue placeholder="בחר עובד" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none" className="text-black">ללא</SelectItem>
                            {employees.map(emp => (
                              <SelectItem key={emp.id} value={emp.id} className="text-black">
                                {emp.full_name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-right block text-black">לקוח</Label>
                        <Select
                          value={taskForm.client_id || 'none'}
                          onValueChange={(value) => setTaskForm({ ...taskForm, client_id: value === 'none' ? null : value })}
                        >
                          <SelectTrigger className="text-black">
                            <SelectValue placeholder="בחר לקוח" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none" className="text-black">ללא</SelectItem>
                            {clients.map(client => (
                              <SelectItem key={client.id} value={client.id} className="text-black">
                                {client.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-right block text-black">פרויקט</Label>
                        <Select
                          value={taskForm.project_id || 'none'}
                          onValueChange={(value) => setTaskForm({ ...taskForm, project_id: value === 'none' ? null : value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="בחר פרויקט" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">ללא</SelectItem>
                            {projects.map(project => (
                              <SelectItem key={project.id} value={project.id}>
                                {project.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label className="text-right block">תיאור</Label>
                      <Textarea
                        value={taskForm.description || ''}
                        onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                        rows={3}
                      />
                    </div>

                    <div className="flex flex-row-reverse gap-2 pt-4">
                      <Button type="submit" className="flex-1">
                        {editingTask ? 'עדכן' : 'צור משימה'}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => {
                        setTaskDialogOpen(false);
                        resetTaskForm();
                      }}>
                        ביטול
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {tasksLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : sortedTasks.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <CheckSquare className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground text-center">
                    אין משימות. לחץ על "משימה חדשה" להוספה.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEnd}
              >
                <SortableContext
                  items={sortedTasks.map(t => t.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="space-y-2">
                    {sortedTasks.map((task, index) => (
                      <SortableTaskItem
                        key={task.id}
                        task={task}
                        index={index}
                        onEdit={handleEditTask}
                        onDelete={handleDeleteTask}
                        onToggleComplete={handleToggleComplete}
                        getPriorityInfo={getPriorityInfo}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            )}
          </TabsContent>

          {/* Meetings Tab */}
          <TabsContent value="meetings" className="space-y-4">
            <div className="flex items-center justify-end">
              <Dialog open={meetingDialogOpen} onOpenChange={(open) => {
                setMeetingDialogOpen(open);
                if (!open) resetMeetingForm();
              }}>
                <DialogTrigger asChild>
                  <Button className="gap-2">
                    <Plus className="h-4 w-4" />
                    פגישה חדשה
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg" dir="rtl">
                  <DialogHeader>
                    <DialogTitle>{editingMeeting ? 'עריכת פגישה' : 'פגישה חדשה'}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleMeetingSubmit} className="space-y-4 text-right">
                    <div>
                      <Label className="text-right block">כותרת *</Label>
                      <Input
                        value={meetingForm.title}
                        onChange={(e) => setMeetingForm({ ...meetingForm, title: e.target.value })}
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-right block">התחלה *</Label>
                        <Input
                          type="datetime-local"
                          value={meetingForm.start_time}
                          onChange={(e) => setMeetingForm({ ...meetingForm, start_time: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label className="text-right block">סיום *</Label>
                        <Input
                          type="datetime-local"
                          value={meetingForm.end_time}
                          onChange={(e) => setMeetingForm({ ...meetingForm, end_time: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-right block">סוג פגישה</Label>
                        <Select
                          value={meetingForm.meeting_type}
                          onValueChange={(value) => setMeetingForm({ ...meetingForm, meeting_type: value })}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {meetingTypes.map(type => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-right block">מיקום</Label>
                        <Input
                          value={meetingForm.location || ''}
                          onChange={(e) => setMeetingForm({ ...meetingForm, location: e.target.value })}
                          placeholder="כתובת / לינק"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-right block">לקוח</Label>
                        <Select
                          value={meetingForm.client_id || 'none'}
                          onValueChange={(value) => setMeetingForm({ ...meetingForm, client_id: value === 'none' ? null : value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="בחר לקוח" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">ללא</SelectItem>
                            {clients.map(client => (
                              <SelectItem key={client.id} value={client.id}>
                                {client.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-right block">פרויקט</Label>
                        <Select
                          value={meetingForm.project_id || 'none'}
                          onValueChange={(value) => setMeetingForm({ ...meetingForm, project_id: value === 'none' ? null : value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="בחר פרויקט" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="none">ללא</SelectItem>
                            {projects.map(project => (
                              <SelectItem key={project.id} value={project.id}>
                                {project.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label className="text-right block">תיאור</Label>
                      <Textarea
                        value={meetingForm.description || ''}
                        onChange={(e) => setMeetingForm({ ...meetingForm, description: e.target.value })}
                        rows={3}
                      />
                    </div>

                    <div className="flex flex-row-reverse gap-2 pt-4">
                      <Button type="submit" className="flex-1">
                        {editingMeeting ? 'עדכן' : 'צור פגישה'}
                      </Button>
                      <Button type="button" variant="outline" onClick={() => {
                        setMeetingDialogOpen(false);
                        resetMeetingForm();
                      }}>
                        ביטול
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {meetingsLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : meetings.length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground text-center">
                    אין פגישות. לחץ על "פגישה חדשה" להוספה.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {meetings.map((meeting) => {
                  const TypeIcon = getTypeIcon(meeting.meeting_type);
                  return (
                    <Card key={meeting.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between flex-row-reverse">
                          <div className="flex gap-4 flex-row-reverse">
                            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-[hsl(220,60%,25%)]/10">
                              <TypeIcon className="h-6 w-6 text-[hsl(220,60%,25%)]" />
                            </div>
                            <div className="text-right">
                              <h3 className="font-semibold text-foreground">{meeting.title}</h3>
                              <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1 justify-end">
                                {meeting.location && (
                                  <span className="flex items-center gap-1">
                                    {meeting.location}
                                    <MapPin className="h-3 w-3" />
                                  </span>
                                )}
                                <span className="flex items-center gap-1">
                                  {format(parseISO(meeting.start_time), 'dd/MM HH:mm', { locale: he })}
                                  {' - '}
                                  {format(parseISO(meeting.end_time), 'HH:mm', { locale: he })}
                                  <Clock className="h-3 w-3" />
                                </span>
                              </div>
                              <div className="flex items-center gap-2 mt-2 justify-end">
                                {meeting.project?.name && (
                                  <Badge variant="outline">
                                    {meeting.project.name}
                                    <Briefcase className="h-3 w-3 mr-1" />
                                  </Badge>
                                )}
                                {meeting.client?.name && (
                                  <Badge variant="outline">
                                    {meeting.client.name}
                                    <Users className="h-3 w-3 mr-1" />
                                  </Badge>
                                )}
                                <Badge className={statusColors[meeting.status] || 'bg-gray-100'}>
                                  {meeting.status === 'scheduled' && 'מתוכנן'}
                                  {meeting.status === 'completed' && 'הושלם'}
                                  {meeting.status === 'cancelled' && 'בוטל'}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEditMeeting(meeting)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteMeeting(meeting.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
};

export default TasksAndMeetings;
