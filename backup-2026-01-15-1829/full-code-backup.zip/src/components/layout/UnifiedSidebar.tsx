// Unified Sidebar - Desktop overlay with auto-hide + Mobile sheet
// Combines best of AppSidebar and OverlaySidebar

import React, { useState, useEffect, useCallback } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Calendar,
  Settings,
  Database,
  History,
  HelpCircle,
  UserCog,
  Clock,
  Table,
  Pin,
  PinOff,
  Upload,
  Bell,
  FileSpreadsheet,
  Wallet,
  Building2,
  X,
  Menu,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { 
  Tooltip, 
  TooltipContent, 
  TooltipTrigger,
  TooltipProvider 
} from '@/components/ui/tooltip';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { useCustomTables } from '@/hooks/useCustomTables';
import { cn } from '@/lib/utils';
import { SidebarTasksMeetings } from './sidebar-tasks';

// ============ NAVIGATION CONFIG ============
const mainNavItems = [
  { title: 'לוח בקרה', url: '/', icon: LayoutDashboard },
  { title: 'היום שלי', url: '/my-day', icon: Calendar },
  { title: 'לקוחות', url: '/clients', icon: Users },
  { title: 'טבלת לקוחות', url: '/datatable-pro', icon: Table },
  { title: 'עובדים', url: '/employees', icon: UserCog },
  { title: 'לוגי זמן', url: '/time-logs', icon: Clock },
  { title: 'ניתוח זמנים', url: '/time-analytics', icon: Clock },
  { title: 'משימות ופגישות', url: '/tasks-meetings', icon: Calendar },
  { title: 'תזכורות', url: '/reminders', icon: Bell },
  { title: 'הצעות מחיר', url: '/quotes', icon: FileSpreadsheet },
  { title: 'כספים', url: '/finance', icon: Wallet },
  { title: 'דוחות', url: '/reports', icon: FileSpreadsheet },
  { title: 'לוח שנה', url: '/calendar', icon: Calendar },
];

const systemNavItems = [
  { title: 'ייבוא נתונים', url: '/data-import', icon: Upload },
  { title: 'גיבויים', url: '/backups', icon: Database },
  { title: 'היסטוריה', url: '/history', icon: History },
  { title: 'הגדרות', url: '/settings', icon: Settings },
  { title: 'עזרה', url: '/help', icon: HelpCircle },
];

// ============ COLORS ============
const colors = {
  navy: '#1e293b',
  navyDark: '#0f172a',
  gold: '#ffd700',
  goldMuted: 'rgba(255, 215, 0, 0.3)',
  textLight: '#e2e8f0',
  textMuted: '#94a3b8',
};

// ============ TYPES ============
interface UnifiedSidebarProps {
  isMobile: boolean;
  mobileOpen?: boolean;
  onMobileOpenChange?: (open: boolean) => void;
}

// ============ MAIN COMPONENT ============
export function UnifiedSidebar({ 
  isMobile, 
  mobileOpen = false, 
  onMobileOpenChange 
}: UnifiedSidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { tables } = useCustomTables();
  
  // Desktop state
  const [isPinned, setIsPinned] = useState(() => {
    const saved = localStorage.getItem('sidebar-pinned');
    return saved === 'true';
  });
  
  const [isHovering, setIsHovering] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  
  const [width, setWidth] = useState(() => {
    const saved = localStorage.getItem('sidebar-width');
    return saved ? parseInt(saved) : 280;
  });

  // Save state to localStorage
  useEffect(() => {
    localStorage.setItem('sidebar-pinned', String(isPinned));
  }, [isPinned]);

  useEffect(() => {
    localStorage.setItem('sidebar-width', String(width));
  }, [width]);

  // Desktop: Mouse edge detection for auto-open
  useEffect(() => {
    if (isMobile || isPinned) return;

    const handleMouseMove = (e: MouseEvent) => {
      const edgeThreshold = 15;
      const screenWidth = window.innerWidth;
      
      if (screenWidth - e.clientX <= edgeThreshold) {
        setIsHovering(true);
      } else if (e.clientX < screenWidth - width - 50) {
        setIsHovering(false);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [isMobile, isPinned, width]);

  // Handle resize dragging
  useEffect(() => {
    if (!isResizing) return;

    document.body.style.userSelect = 'none';
    document.body.style.cursor = 'ew-resize';

    const handleMouseMove = (e: MouseEvent) => {
      const newWidth = window.innerWidth - e.clientX;
      if (newWidth >= 220 && newWidth <= 500) {
        setWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
      document.body.style.userSelect = '';
      document.body.style.cursor = '';
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizing]);

  // Notify parent about content margin needed
  useEffect(() => {
    if (isMobile) return;
    
    const marginNeeded = isPinned ? width : 0;
    window.dispatchEvent(new CustomEvent('sidebarMarginChange', { 
      detail: { margin: marginNeeded } 
    }));
  }, [isPinned, width, isMobile]);

  const isActive = (path: string) => location.pathname === path;
  const shouldShow = isPinned || isHovering;

  const handleNavClick = (url: string) => {
    navigate(url);
    if (isMobile && onMobileOpenChange) {
      onMobileOpenChange(false);
    }
  };

  // ============ SIDEBAR CONTENT (shared) ============
  const SidebarContent = ({ inSheet = false }: { inSheet?: boolean }) => (
    <div className="flex flex-col h-full" dir="rtl">
      {/* Header */}
      <div 
        className="flex items-center justify-between p-4 border-b"
        style={{ 
          borderColor: colors.goldMuted, 
          backgroundColor: colors.navy 
        }}
      >
        <div className="flex items-center gap-3">
          <div 
            className="flex h-10 w-10 items-center justify-center rounded-lg shadow-md"
            style={{ backgroundColor: colors.gold, color: colors.navyDark }}
          >
            <Building2 className="h-5 w-5" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-lg text-white">e-control</span>
            <span className="text-xs" style={{ color: colors.gold }}>CRM Pro Max</span>
          </div>
        </div>
        
        {/* Pin button - only on desktop */}
        {!inSheet && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsPinned(!isPinned)}
                className={cn(
                  "transition-colors",
                  isPinned 
                    ? "hover:bg-yellow-500/30" 
                    : "text-gray-400 hover:text-white hover:bg-blue-800"
                )}
                style={isPinned ? { color: colors.gold, backgroundColor: 'rgba(255, 215, 0, 0.2)' } : {}}
              >
                {isPinned ? <Pin className="h-5 w-5" /> : <PinOff className="h-5 w-5" />}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="left">
              <p className="text-xs">
                {isPinned ? "בטל נעיצה - הסרגל יסתתר" : "נעץ - הסרגל יישאר פתוח"}
              </p>
            </TooltipContent>
          </Tooltip>
        )}

        {/* Close button - only in mobile sheet */}
        {inSheet && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onMobileOpenChange?.(false)}
            className="text-gray-400 hover:text-white hover:bg-red-500/20"
          >
            <X className="h-5 w-5" />
          </Button>
        )}
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 p-3">
        {/* Main Nav */}
        <div className="space-y-1 mb-4">
          <p 
            className="text-xs font-semibold px-3 py-2 uppercase tracking-wider"
            style={{ color: colors.gold }}
          >
            ניווט ראשי
          </p>
          {mainNavItems.map((item) => (
            <button
              key={item.url}
              onClick={() => handleNavClick(item.url)}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm w-full text-right",
                isActive(item.url)
                  ? "font-medium shadow-lg"
                  : "text-gray-300 hover:bg-blue-800 hover:text-white"
              )}
              style={isActive(item.url) ? { backgroundColor: colors.gold, color: colors.navyDark } : {}}
            >
              <item.icon className="h-5 w-5 shrink-0" />
              <span>{item.title}</span>
            </button>
          ))}
        </div>

        {/* Tasks & Meetings Widget */}
        <div className="my-4 px-1">
          <SidebarTasksMeetings isCollapsed={false} />
        </div>

        <Separator className="my-4" style={{ backgroundColor: colors.goldMuted }} />

        {/* Custom Tables */}
        {tables && tables.length > 0 && (
          <>
            <div className="space-y-1 mb-4">
              <div className="flex items-center gap-2 px-3 py-2">
                <Table className="h-4 w-4" style={{ color: colors.gold }} />
                <p 
                  className="text-xs font-semibold uppercase tracking-wider"
                  style={{ color: colors.gold }}
                >
                  טבלאות מותאמות
                </p>
                <Badge 
                  variant="secondary" 
                  className="text-[10px] px-1.5 h-4 border-0"
                  style={{ backgroundColor: 'rgba(255, 215, 0, 0.2)', color: colors.gold }}
                >
                  {tables.length}
                </Badge>
              </div>
              <div 
                className="border rounded-lg p-1"
                style={{ borderColor: colors.goldMuted, backgroundColor: 'rgba(255, 215, 0, 0.05)' }}
              >
                {tables.map((table) => (
                  <button
                    key={table.id}
                    onClick={() => handleNavClick(`/custom-table/${table.id}`)}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm w-full text-right",
                      location.pathname === `/custom-table/${table.id}`
                        ? "font-medium shadow-lg"
                        : "hover:bg-yellow-500/20"
                    )}
                    style={
                      location.pathname === `/custom-table/${table.id}` 
                        ? { backgroundColor: colors.gold, color: colors.navyDark }
                        : { color: colors.gold }
                    }
                  >
                    <Table className="h-5 w-5 shrink-0" />
                    <span>{table.display_name}</span>
                  </button>
                ))}
              </div>
            </div>
            <Separator className="my-4" style={{ backgroundColor: colors.goldMuted }} />
          </>
        )}

        {/* System Nav */}
        <div className="space-y-1">
          <p 
            className="text-xs font-semibold px-3 py-2 uppercase tracking-wider"
            style={{ color: colors.gold }}
          >
            מערכת
          </p>
          {systemNavItems.map((item) => (
            <button
              key={item.url}
              onClick={() => handleNavClick(item.url)}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm w-full text-right",
                isActive(item.url)
                  ? "font-medium shadow-lg"
                  : "text-gray-300 hover:bg-blue-800 hover:text-white"
              )}
              style={isActive(item.url) ? { backgroundColor: colors.gold, color: colors.navyDark } : {}}
            >
              <item.icon className="h-5 w-5 shrink-0" />
              <span>{item.title}</span>
            </button>
          ))}
        </div>
      </ScrollArea>

      {/* Footer */}
      <div 
        className="p-3 border-t text-center"
        style={{ borderColor: colors.goldMuted }}
      >
        <span className="text-xs" style={{ color: colors.textMuted }}>
          גרסה 2.0.0
        </span>
      </div>
    </div>
  );

  // ============ MOBILE: Sheet ============
  if (isMobile) {
    return (
      <Sheet open={mobileOpen} onOpenChange={onMobileOpenChange}>
        <SheetContent 
          side="right" 
          className="w-[85vw] max-w-[320px] p-0 border-0"
          style={{ backgroundColor: colors.navy }}
        >
          <SidebarContent inSheet />
        </SheetContent>
      </Sheet>
    );
  }

  // ============ DESKTOP: Overlay Sidebar ============
  return (
    <TooltipProvider>
      <div
        className="fixed top-0 right-0 h-full shadow-2xl"
        style={{
          width: `${width}px`,
          transform: shouldShow ? 'translateX(0)' : 'translateX(100%)',
          transition: 'transform 300ms ease-out',
          zIndex: 100,
          backgroundColor: colors.navy,
          borderLeft: `3px solid ${colors.gold}`,
          borderRadius: '12px 0 0 12px',
        }}
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => !isPinned && setIsHovering(false)}
      >
        {/* Resize Handle */}
        <Tooltip>
          <TooltipTrigger asChild>
            <div
              className="absolute left-0 top-0 h-full w-2 cursor-ew-resize hover:bg-yellow-500/30 transition-colors group flex items-center"
              style={{ backgroundColor: isResizing ? 'rgba(255, 215, 0, 0.3)' : 'transparent' }}
              onMouseDown={(e) => {
                e.preventDefault();
                setIsResizing(true);
              }}
            >
              <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity mx-auto">
                <div className="w-0.5 h-1 bg-gray-400 rounded-full" />
                <div className="w-0.5 h-1 bg-gray-400 rounded-full" />
                <div className="w-0.5 h-1 bg-gray-400 rounded-full" />
              </div>
            </div>
          </TooltipTrigger>
          <TooltipContent side="left">
            <p className="text-xs">גרור לשינוי רוחב</p>
          </TooltipContent>
        </Tooltip>

        <SidebarContent />
      </div>
    </TooltipProvider>
  );
}

export default UnifiedSidebar;
