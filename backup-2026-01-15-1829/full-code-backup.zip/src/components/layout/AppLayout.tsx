// App Layout - Unified layout with single sidebar system
import React, { useState, useEffect } from 'react';
import { AppHeader } from './AppHeader';
import { FloatingTimer } from '@/components/timer/FloatingTimer';
import { useIsMobile } from '@/hooks/use-mobile';
import { UnifiedSidebar } from './UnifiedSidebar';

interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export function AppLayout({ children, title }: AppLayoutProps) {
  const isMobile = useIsMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [contentMargin, setContentMargin] = useState(0);

  // Listen for sidebar margin changes (from UnifiedSidebar)
  useEffect(() => {
    const handleMarginChange = (e: CustomEvent<{ margin: number }>) => {
      setContentMargin(e.detail.margin);
    };

    window.addEventListener('sidebarMarginChange', handleMarginChange as EventListener);
    
    // Initialize from localStorage
    const isPinned = localStorage.getItem('sidebar-pinned') === 'true';
    const width = parseInt(localStorage.getItem('sidebar-width') || '280');
    if (!isMobile && isPinned) {
      setContentMargin(width);
    }

    return () => {
      window.removeEventListener('sidebarMarginChange', handleMarginChange as EventListener);
    };
  }, [isMobile]);

  return (
    <div className="min-h-screen w-full bg-background overflow-x-hidden">
      {/* Main Content */}
      <div 
        className="flex flex-col min-h-screen w-full max-w-full transition-all duration-300 ease-out"
        style={{ marginRight: isMobile ? 0 : contentMargin }}
      >
        <AppHeader 
          title={title} 
          onMobileMenuToggle={() => setMobileMenuOpen(true)}
          isMobile={isMobile}
        />
        <main className="flex-1 overflow-auto relative w-full max-w-full z-0">
          {children}
        </main>
      </div>
      
      {/* Unified Sidebar - handles both mobile and desktop */}
      <UnifiedSidebar 
        isMobile={isMobile}
        mobileOpen={mobileMenuOpen}
        onMobileOpenChange={setMobileMenuOpen}
      />
      
      {/* Floating Timer Button */}
      <FloatingTimer />
    </div>
  );
}
