export { AppLayout } from './AppLayout';
export { AppHeader } from './AppHeader';
export { UnifiedSidebar } from './UnifiedSidebar';

// Legacy exports (deprecated - use UnifiedSidebar instead)
export { AppSidebar } from './AppSidebar';
export { OverlaySidebar } from './OverlaySidebar';
